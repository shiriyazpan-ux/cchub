import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "ניהול משימות לפי לקוח: למה זה משנה את כל העבודה? | CCHUB",
  description: "למה ניהול משימות לפי לקוח ונכס דיגיטלי חשוב יותר מרשימת משימות כללית, ואיך זה עוזר לשלוט בזמן, עלויות והיסטוריית עבודה.",
  alternates: { canonical: "/articles/tasks-by-client" },
  openGraph: {
    title: "ניהול משימות לפי לקוח: למה זה משנה את כל העבודה? | CCHUB",
    description: "למה ניהול משימות לפי לקוח ונכס דיגיטלי חשוב יותר מרשימת משימות כללית, ואיך זה עוזר לשלוט בזמן, עלויות והיסטוריית עבודה.",
    url: "https://web.mycchub.app/articles/tasks-by-client",
    siteName: "CCHUB",
    locale: "he_IL",
    type: "article",
  },
};

export default function ArticlePage() {
  return (
    <main dir="rtl" className="min-h-screen bg-[#F6FAFF] text-[#071B4D]">

      <article className="cchub-container py-16">
        <div className="mx-auto max-w-4xl text-center">
          <span className="cchub-trial-badge-strong">מאמר מקצועי</span>
          <h1 className="cchub-title-xl mt-5">ניהול משימות לפי לקוח: למה זה משנה את כל העבודה?</h1>
          <p className="cchub-text mt-5">רשימת משימות כללית יכולה להיראות מסודרת, אבל ברגע שיש כמה לקוחות, כמה נכסים והרבה פרטים קטנים — היא מהר מאוד מאבדת הקשר.</p>
        </div>

        <div className="mx-auto mt-10 grid max-w-5xl gap-7 lg:grid-cols-[1fr_0.75fr]">
          <div className="grid gap-6">

          <section className="rounded-3xl border border-blue-100 bg-white p-7 shadow-sm">
            <h2 className="text-3xl font-black leading-tight">משימה בלי לקוח היא מידע חסר</h2>
            <p className="mt-4 leading-9 text-slate-600">כשמשימה לא משויכת ללקוח, קשה להבין למי היא שייכת, למה היא נפתחה, איזה מסמכים קשורים אליה ומה ההשלכות שלה. שיוך ללקוח הופך את המשימה לחלק מתהליך.</p>
          </section>
          <section className="rounded-3xl border border-blue-100 bg-white p-7 shadow-sm">
            <h2 className="text-3xl font-black leading-tight">משימה צריכה להיות מחוברת גם לנכס</h2>
            <p className="mt-4 leading-9 text-slate-600">בעסקים שמנהלים אתרים, דומיינים, מערכות או חשבונות פרסום, לא מספיק לדעת מי הלקוח. צריך לדעת גם על איזה נכס עובדים. כך נמנעות טעויות ובלבול.</p>
          </section>
          <section className="rounded-3xl border border-blue-100 bg-white p-7 shadow-sm">
            <h2 className="text-3xl font-black leading-tight">זמן ועלויות נותנים תמונה עסקית</h2>
            <p className="mt-4 leading-9 text-slate-600">כאשר משימה כוללת זמן עבודה, הערכת שעות ועלות, היא כבר לא רק תזכורת. היא הופכת לכלי שמראה כמה עבודה הושקעה ומה המשמעות הכלכלית שלה.</p>
          </section>
          <section className="rounded-3xl border border-blue-100 bg-white p-7 shadow-sm">
            <h2 className="text-3xl font-black leading-tight">היסטוריה מסודרת חוסכת שאלות חוזרות</h2>
            <p className="mt-4 leading-9 text-slate-600">כשמשימות נשמרות לפי לקוח, קל לחזור אחורה, להבין מה בוצע, מי טיפל, מתי זה נסגר ומה נשאר להמשך. זה חשוב במיוחד עם לקוחות קבועים.</p>
          </section>
          </div>

          <aside className="grid content-start gap-5">
            <div className="cchub-card p-6">
              <h2 className="text-2xl font-black">מה לקחת מהמאמר?</h2>
              <div className="mt-4 grid gap-3">

                <div className="price-row rounded-2xl border border-blue-100 bg-blue-50 p-4">
                  <span className="price-row-mark">✓</span>
                  <span className="price-row-text font-black">משימה חייבת הקשר ללקוח.</span>
                </div>
                <div className="price-row rounded-2xl border border-blue-100 bg-blue-50 p-4">
                  <span className="price-row-mark">✓</span>
                  <span className="price-row-text font-black">נכס דיגיטלי עוזר להבין איפה העבודה בוצעה.</span>
                </div>
                <div className="price-row rounded-2xl border border-blue-100 bg-blue-50 p-4">
                  <span className="price-row-mark">✓</span>
                  <span className="price-row-text font-black">זמן ועלויות הופכים משימה לכלי ניהולי.</span>
                </div>
              </div>
            </div>

            <div className="cchub-card p-6">
              <h2 className="text-2xl font-black">ממשיכים מכאן</h2>
              <p className="mt-3 leading-8 text-slate-600">
                אחרי שמבינים את העיקרון, השלב הבא הוא לראות איך זה מתחבר לעבודה יומיומית בתוך מערכת אחת.
              </p>
              <div className="mt-5 grid gap-3">
                <a className="cchub-button-primary justify-center" href="/tutorials/add-task">למדריך הוספת משימה</a>
                <a className="cchub-button-secondary justify-center" href="/features">צפייה ביכולות המערכת</a>
              </div>
            </div>
          </aside>
        </div>

        <div className="mx-auto mt-10 max-w-5xl rounded-[30px] bg-[#061A44] p-8 text-center text-white">
          <span className="inline-flex rounded-full bg-white/10 px-5 py-2 text-sm font-black text-blue-100">14 ימי ניסיון חינם</span>
          <h2 className="mt-4 text-3xl font-black">רוצים להפוך את זה לשיטת עבודה אמיתית?</h2>
          <p className="mx-auto mt-3 max-w-2xl text-blue-100">
            CCHUB מרכזת לקוחות, משימות, מסמכים, סיסמאות, נכסים דיגיטליים וידע כדי שהמידע לא יישאר מפוזר.
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-4">
            <a className="cchub-button-primary" href="/pricing">התחילו 14 ימי ניסיון חינם</a>
            <a className="cchub-button-dark" href="/tutorials">מעבר לטוטריאלים</a>
          </div>
        </div>
      </article>
    </main>
  );
}
