import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "איך לנהל לקוחות קבועים בלי לאבד מידע? | CCHUB",
  description: "שיטה לניהול לקוחות קבועים לאורך זמן באמצעות תיק לקוח, משימות, מסמכים, סיסמאות, נכסים דיגיטליים ומרכז ידע.",
  alternates: { canonical: "/articles/manage-long-term-clients" },
  openGraph: {
    title: "איך לנהל לקוחות קבועים בלי לאבד מידע? | CCHUB",
    description: "שיטה לניהול לקוחות קבועים לאורך זמן באמצעות תיק לקוח, משימות, מסמכים, סיסמאות, נכסים דיגיטליים ומרכז ידע.",
    url: "https://web.mycchub.app/articles/manage-long-term-clients",
    siteName: "CCHUB",
    locale: "he_IL",
    type: "article",
  },
};

export default function ArticlePage() {
  return (
    <main dir="rtl" className="min-h-screen bg-[#F6FAFF] text-[#071B4D]">

      <article className="cchub-container py-16">
        <div className="mx-auto max-w-4xl text-center">
          <span className="cchub-trial-badge-strong">מאמר מקצועי</span>
          <h1 className="cchub-title-xl mt-5">איך לנהל לקוחות קבועים בלי לאבד מידע?</h1>
          <p className="cchub-text mt-5">לקוחות קבועים הם נכס, אבל הם גם מייצרים הרבה מידע לאורך זמן. בלי שיטה, כל חודש מוסיף עוד שכבת בלגן.</p>
        </div>

        <div className="mx-auto mt-10 grid max-w-5xl gap-7 lg:grid-cols-[1fr_0.75fr]">
          <div className="grid gap-6">

          <section className="rounded-3xl border border-blue-100 bg-white p-7 shadow-sm">
            <h2 className="text-3xl font-black leading-tight">תיק לקוח הוא הבית של המידע</h2>
            <p className="mt-4 leading-9 text-slate-600">במקום לשמור מידע לפי המקום שבו הוא נוצר, שומרים אותו לפי הלקוח שאליו הוא שייך. כך כל משימה, מסמך, סיסמה והחלטה מקבלים הקשר ברור.</p>
          </section>
          <section className="rounded-3xl border border-blue-100 bg-white p-7 shadow-sm">
            <h2 className="text-3xl font-black leading-tight">היסטוריה חשובה לא פחות מהמשימה הנוכחית</h2>
            <p className="mt-4 leading-9 text-slate-600">עם לקוחות קבועים, צריך לדעת לא רק מה פתוח עכשיו אלא גם מה בוצע בעבר, מה הוחלט, אילו גישות קיימות ומה השתנה לאורך זמן.</p>
          </section>
          <section className="rounded-3xl border border-blue-100 bg-white p-7 shadow-sm">
            <h2 className="text-3xl font-black leading-tight">אל תסמכו על זיכרון אישי</h2>
            <p className="mt-4 leading-9 text-slate-600">גם אם אדם אחד בעסק זוכר הכול, זה לא תהליך יציב. מידע עסקי צריך להיות מתועד כך שכל מי שמורשה יוכל להבין את מצב הלקוח.</p>
          </section>
          <section className="rounded-3xl border border-blue-100 bg-white p-7 shadow-sm">
            <h2 className="text-3xl font-black leading-tight">תיעוד קטן חוסך שיחות גדולות</h2>
            <p className="mt-4 leading-9 text-slate-600">הוספת הערה, סגירת משימה עם פירוט, שמירת מסמך במקום הנכון — כל אלה חוסכים חיפוש, שאלות חוזרות וטעויות בהמשך.</p>
          </section>
          </div>

          <aside className="grid content-start gap-5">
            <div className="cchub-card p-6">
              <h2 className="text-2xl font-black">מה לקחת מהמאמר?</h2>
              <div className="mt-4 grid gap-3">

                <div className="price-row rounded-2xl border border-blue-100 bg-blue-50 p-4">
                  <span className="price-row-mark">✓</span>
                  <span className="price-row-text font-black">כל לקוח צריך תיק מרכזי.</span>
                </div>
                <div className="price-row rounded-2xl border border-blue-100 bg-blue-50 p-4">
                  <span className="price-row-mark">✓</span>
                  <span className="price-row-text font-black">היסטוריה מסודרת שווה כסף.</span>
                </div>
                <div className="price-row rounded-2xl border border-blue-100 bg-blue-50 p-4">
                  <span className="price-row-mark">✓</span>
                  <span className="price-row-text font-black">תיעוד לא צריך להיות מסובך כדי להיות יעיל.</span>
                </div>
              </div>
            </div>

            <div className="cchub-card p-6">
              <h2 className="text-2xl font-black">ממשיכים מכאן</h2>
              <p className="mt-3 leading-8 text-slate-600">
                אחרי שמבינים את העיקרון, השלב הבא הוא להפוך אותו לתהליך קבוע
                בתוך העבודה היומיומית של העסק.
              </p>
              <div className="mt-5 grid gap-3">
                <a className="cchub-button-primary justify-center" href="/tutorials/add-client">למדריך הוספת לקוח</a>
                <a className="cchub-button-secondary justify-center" href="/features">צפייה ביכולות המערכת</a>
              </div>
            </div>
          </aside>
        </div>

        <div className="mx-auto mt-10 max-w-5xl rounded-[30px] bg-[#061A44] p-8 text-center text-white">
          <span className="inline-flex rounded-full bg-white/10 px-5 py-2 text-sm font-black text-blue-100">14 ימי ניסיון חינם</span>
          <h2 className="mt-4 text-3xl font-black">רוצים לראות איך זה עובד בפועל?</h2>
          <p className="mx-auto mt-3 max-w-2xl text-blue-100">
            CCHUB מרכזת לקוחות, משימות, מסמכים, סיסמאות, נכסים דיגיטליים וידע
            במקום אחד — כדי שהעסק יעבוד מסודר יותר.
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-4">
            <a className="cchub-button-primary" href="/pricing">התחילו 14 ימי ניסיון חינם</a>
            <a className="cchub-button-dark" href="/tutorials">מעבר לטוטריאלים</a>
          </div>
        </div>
      </article>
    </main>
  );
}
